****HOW TO RUN THE PROGRAM PLAGIARISMCATCHER******

1. First unzip the folder named cheaters_xxxxx.zip
2. Type in module load gcc in command line 
3. Type make 
4. Enter command line argument as ./plagiarismCatcher "directorypath" "chunkSize" "minimum similarities" where inside the double quote goes actual values 
5. The program should run once you enter the command